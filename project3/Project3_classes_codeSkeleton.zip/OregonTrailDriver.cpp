// CS1300 Fall 2020
// Author: Eric Huynh
// Recitation: 221 – Sanskar Katiyar
// Project 3
#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include "Traveler.h" //reference to blueprint file

using namespace std;

void savedata()
{
    //this function will write to a file to save a user's data and stats whether they finish the game or not
}

int randnumbers()
{
    //this function is used to randomize different possibilities in certain scenarios like hunting and misfortunes
}

bool puzzle()
{
    //this is where the puzzle will be that the user will have to solve in order to win a hunt or fight off raider attacks
    //for the puzzle, it may be a guessing number system but it may be something else.
}

void raiderattack()
{
    //this is where the simulation of raider attacks will be (with a certain probability)
    //the user will be given options to either run, fight or surrender and there will be statements for each option
}

void misfortune()
{
    //this is where the simulation of misfortunes will be (with a probablity of 40% to be caused)
    /*The misfortunes can be: a person in the party gets sick (typhoid, cholera, diarrhea, measles, dysentery, and fever),
    an oxen dies, or one of the wagon parts break down
    */
    //depend on the misfortune, there will be consequences/options for the user to help with their situation
}

void usermenu()
{
    //this is where each turn of the game will be simulated, also given the status update of the user
    //the user will be given the options to either stop and rest, continue on, hunt for animals, or quit the game and will also have different statements for each option
}

void store()
{
    //this is where the shop simulation for the game will be
    //the user will get to buy materials before they go on their journey on the trail
    //there will also be an implementation of increased prices depending at which fort the user arrives at
}

int main()
{
    int miles = 0;
    cout << "Hello and Welcome to the Oregon Trail!" << endl;
    Traveler user = Traveler();
    store();
    while(miles < 2048)
    {
        //each function/class will probably run under this loop
    }
}